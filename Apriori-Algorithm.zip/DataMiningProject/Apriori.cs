﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Text;

namespace DataminingProject
{
    public class Apriori
    {
        private double support_count;
        private double min_confidence;
        private string[][] dataset;

        private ArrayList AllFreqItemSetsLists;
        private FreqItemSetsList allFreqItemSets;
        

        public double Min_Support
        {

            get
            {
                return support_count;
            }
        }
        public FreqItemSetsList AllFrequentList
        {
            get
            {

                return allFreqItemSets;
            }
            set
            {

                allFreqItemSets = value;
            }
        }
        public ArrayList AllFrequentItemSetsLists {

            get {
                return AllFreqItemSetsLists;
            }
        
        }
        
        public Apriori(string[][] data, double min_sup, double min_confid)
        {
            dataset = data;
            support_count = (min_sup * (data.GetUpperBound(0) + 1)) / 100;
            min_confidence = min_confid;
            AllFreqItemSetsLists = new ArrayList();
            allFreqItemSets = new FreqItemSetsList();

        }//end constructor


        /// <summary>
        /// find the frequent 1-item itemset in the given dataset with respect to the threshold 
        /// given to the algorithm (min_support)
        /// </summary>
        /// <param name="dataset"></param>
        /// <returns>ItemSet[] L1</returns>

        ItemSet[] find_frequent_1_itemsets()
        {
            SortedList<string, int> l = new SortedList<string, int>();
            //Hashtable hlist = new Hashtable();

            //scan the dataset for find items
            for (int i = 0; i <= dataset.GetUpperBound(0); i++)
            {
                for (int j = 0; j < dataset[i].Length; j++)
                {
                    if (dataset[i][j] != null && l.ContainsKey(dataset[i][j]))
                    {
                        l[dataset[i][j]]++;
                    }
                    else
                    {
                        if (dataset[i][j] != null)
                            l.Add(dataset[i][j], 1);
                    }

                }//end inner loop
            }//end outer loop
            //the frequent list
            ArrayList list = new ArrayList();

            IList<string> temp_values = l.Keys;
            IList<int> temp_counts = l.Values;

            for (int j = 0; j < l.Count; j++)
            {
                if (temp_counts[j] >= support_count)
                {

                    ArrayList it = new ArrayList();
                    it.Add(temp_values[j]);

                    //list[j] = new ItemSet(s, temp_counts[j]);
                    ItemSet items = new ItemSet(it);
                    items.Count = temp_counts[j];

                    list.Add(items);
                }
            }

            if (list.Count > 0)
            {
                return (ItemSet[])list.ToArray(typeof(ItemSet));
            }
            else
            {
                return null;
            }
        }//end method find_frequent_1_itemsets

        /// <summary>
        /// find the fequent (k)-item itemsets  in the given transaction Candidate list 
        /// </summary>
        /// <param name="Ct"></param>
        /// <returns></returns>

        ItemSet[] find_frequent_K_Itemsets(ItemSet[] Ct)
        {
            ArrayList temp = new ArrayList();
            foreach (ItemSet l in Ct)
            {
                if (l.Count >= support_count)
                {
                    temp.Add(l);
                }

            }

            temp.TrimToSize();
            if (temp.Count > 0)
            {
                return (ItemSet[])temp.ToArray(typeof(ItemSet));
            }
            else
            {
                return null;
            }
        }//end method find_frequent_K_Itemset

        /// <summary>
        /// 
        /// generating the candidate k-items itemsets list that to be tested as frequent or not by 
        /// the algorithm to generate the association rules from (mining association rules)
        /// </summary>
        /// <param name="Lk_1"></param>
        /// <returns></returns>

        private ItemSet[] apriori_gen(ItemSet[] Lk_1)
        {
            if (Lk_1 != null && Lk_1.Length > 0)
            {
                ArrayList Ck = new ArrayList();

                bool flag = true;
                int j;

                //join l1 and l2 
                foreach (ItemSet l1 in Lk_1)
                {

                    foreach (ItemSet l2 in Lk_1)
                    {
                        ItemSet c = new ItemSet();

                        for (j = 0; j < l1.Level - 1; j++)
                        {
                            if (l1.Items[j] != l2.Items[j])
                            {
                                flag = false;
                                break;
                            }

                        }
                        if (flag && ((string)l1.Items[j]).CompareTo((string)l2.Items[j]) < 0)
                        {

                            c.Items.InsertRange(0, l1.Items);
                            c.Items.Add(l2.Items[j]);
                            c.Items.TrimToSize();

                            if (!has_infrequent_subset(c, Lk_1))
                            {
                                Ck.Add(c);
                            }
                            else
                            {
                                c = null;
                            }
                        }
                        flag = true;

                    }//end inner for

                }//end outer for

                ItemSet[] ck = (ItemSet[])Ck.ToArray(typeof(ItemSet));

                return ck;
            }
            else
            {
                return null;
            }


        }//end method apriori_gen

        /// <summary>
        /// start the pruning process .
        /// test if the (k-1)items itemset c has infrequent subset so any subper itemset contain
        /// c will no generated by the apriori algorithm(prune  the tree)
        /// </summary>
        /// <param name="c"></param>
        /// <param name="Lk_1"></param>
        /// <returns></returns>
        private bool has_infrequent_subset(ItemSet c, ItemSet[] Lk_1)
        {
            //int k = Lk_1[0].Items.Count;
            int k = c.Items.Count;
            ArrayList temp = new ArrayList(c.Level);

            for (int i = 0; i < k; i++)
            {
                temp.AddRange(c.Items.GetRange(0, i));
                temp.AddRange(c.Items.GetRange(i + 1, c.Level - i - 1));
                temp.TrimToSize();
                ItemSet s = new ItemSet(temp);
                if (!IsFreq(s, Lk_1))
                {
                    return true;
                }

                temp.Clear();

            }

            return false;
        }//end method has_infrequent_subset

        /// <summary>
        /// test if the itemset s is frequent itemset or not
        /// </summary>
        /// <param name="s"></param>
        /// <param name="Lk_1"></param>
        /// <returns></returns>
        bool IsFreq(ItemSet s, ItemSet[] Lk_1)
        {
            foreach (ItemSet l in Lk_1)
            {

                if (ItemSet.IsEqual(l, s))
                {
                    return true;
                }

            }
            return false;
        }//end method IsFreq

        /// <summary>
        /// get the Ct (the candidate itemsets of the transactions to be frequent itemsets)
        /// </summary>
        /// <param name="Ck"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        private ItemSet[] Subset(ItemSet[] Ck, string[] dt)
        {
            if (Ck != null && Ck.Length > 0)
            {
                int k = Ck[0].Level;
                ArrayList temp = new ArrayList(dt);
                ArrayList Ct = new ArrayList();
                bool flag = true;

                foreach (ItemSet l in Ck)
                {

                    for (int i = 0; i < k; i++)
                    {
                        if (!temp.Contains(l.Items[i]))
                        {
                            flag = false;
                            break;
                        }
                    }
                    if (flag && IsFreq(l, Ck))
                    {
                        Ct.Add(l);
                    }
                    flag = true;


                }


                return (ItemSet[])Ct.ToArray(typeof(ItemSet));
            }
            else
            {
                return null;
            }

        }//end method Subset

        /// <summary>
        /// find the mined assoctiatoin rules ,this method start the mining process 
        /// on the given dataset
        /// </summary>
        /// <param name="dataset"></param>
        /// 
        public void find_assoc_rules()
        {


            ArrayList tempct = new ArrayList();

            ItemSet[] Ct;
            ItemSet[] Ck;
            ItemSet[] Lk;
            //find the 1-item frequent itemset in the dataset
            ItemSet[] L1 = find_frequent_1_itemsets();
            Lk = L1;
            
            AllFreqItemSetsLists.Add(L1);
            allFreqItemSets.AddRange(L1);
            int k;
            for (k = 2; Lk.Length > 1; k++)
            {
                Ck = apriori_gen(Lk);
                if (Ck != null && Ck.Length > 0)
                {
                    for (int i = 0; i <= dataset.GetUpperBound(0); i++)
                    {
                        //find the subset of transaction i that are candidates (Cts)
                        Ct = Subset(Ck, dataset[i]);

                        foreach (ItemSet ct in Ct)
                        {

                            if (tempct.Contains(ct))
                            {
                                ((ItemSet)tempct[tempct.IndexOf(ct)]).Count++;
                            }
                            else
                            {
                                ct.Count++;
                                tempct.Add(ct);
                            }
                        }

                    }
                }

                ItemSet[] Ctt = (ItemSet[])tempct.ToArray(typeof(ItemSet));
                //find the frequent ItemSets in Ctt
                Lk = find_frequent_K_Itemsets(Ctt);
                // Console.WriteLine("Itemset (" + k + ")");

                tempct.Clear();
                if (Lk != null)
                {
                    FreqItemSetsList lk = new FreqItemSetsList();
                    lk.AddRange(Lk);
                    AllFreqItemSetsLists.Add(Lk);                    
                    allFreqItemSets.AddRange(Lk);
                }
                else
                {
                    //exit the loop;
                    break;
                }
            }//end for loop


            
           
            ItemSet.print_AllFrequentList(AllFreqItemSetsLists);

        }//end method find_assoc_rules


        /// <summary>
        /// this method get the association rules that are interesting to the user 
        /// from the give list of all the frequent itemsets in the mined dataset
        /// </summary>
        /// <param name="AllFrequentItemLists"></param>
        /// 
        public List<AssocRule> get_assoc_rules()
        {
            double s_support_count;
            double l_support_count;
            List<AssocRule> tempassoc = new List<AssocRule>();
            foreach (ItemSet l in allFreqItemSets.Values)
            {
                if (l.Level <= 1)
                    continue;
                        
                    ItemSet[] subsets = ItemSet.get_subsets(l);
                   
                    if (subsets.Length > 1 && l.Level > 1)
                    {
                        

                        for (int c = 0; c < subsets.Length; c++)
                        {
                            ItemSet ls = subsets[c];
                            ItemSet rs = ItemSet.Minus(l, ls);
                           

                            if (rs == null || ls == null)
                            {
                                continue;
                            }
                            
                             
                            

                            rs = get_FrequentItemset(rs);
                            s_support_count = get_supportCount(ls);
                            l_support_count = get_supportCount(l);
                            double confidance = Math.Round((l_support_count / s_support_count) * 100,0);

                            if (confidance >= min_confidence)
                            {
                                AssocRule r = new AssocRule(ls, rs, confidance);
                                tempassoc.Add(r);
                                Console.Write("");
                            }
                        }
                    }
                
            }
            
            


            return tempassoc;
        }//end method get_assoc_rules
        
        //get the real itemset from itemset equals to it
        public ItemSet get_FrequentItemset(ItemSet s) {

            if (s != null) {

                ItemSet it = allFreqItemSets.GetItemSet(s);
                return it;
            }
            
            
            return null;
        }

        public int get_supportCount(ItemSet s)
        {
            ItemSet s1=(ItemSet)  get_FrequentItemset(s);
            return s1.Count;
        }


    }//end class  Apriori
}
