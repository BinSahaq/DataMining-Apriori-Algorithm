﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataminingProject
{
    public class AssocRule
    {
        private ItemSet lhs;
        private ItemSet rhs;

        private double confidance;

        public ItemSet LHS {

            get {
                return lhs;
            }
        }
        public ItemSet RHS {

            get {
                return rhs;
            }
        }
        public double Confidance {

            get {

                return confidance;
            }
        }

        public AssocRule(ItemSet l,ItemSet r,double c) {
            lhs = l;
            rhs = r;
            confidance = c;
        }
        
    }
}
