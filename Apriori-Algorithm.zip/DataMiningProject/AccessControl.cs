﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace DataminingProject
{
    public partial class AccessControl : UserControl
    {
        //data member

        OpenFileDialog filedlg;
        string filename;

        public string FileName {

            get {

                return filename;

            }
        }

        //constructor
        public AccessControl()
        {
            InitializeComponent();
            filedlg = new OpenFileDialog();
            filedlg.Filter = "Access Office Access(*.accdb,*.mdb)|*.accdb;*.mdb";
            filename = "";
        }

        private void btn_browse_Click(object sender, EventArgs e)
        {
            if (filedlg.ShowDialog() == DialogResult.OK) {
                if (filedlg.FileName != "") {
                    txt_filename.Text = filedlg.FileName;
                    filename = txt_filename.Text;
                }
            
            }

            }

        private void txt_filename_TextChanged(object sender, EventArgs e)
        {
            filename = txt_filename.Text;
        }//


    }//end AccessControl
}//end namespace
