﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace DataminingProject
{
    public class FreqItemSetsList : Dictionary<int,ItemSet>
    {   
        public FreqItemSetsList()
        {
            

        }
        public void AddItemSet(ItemSet item)
        {   

            base.Add(GetItemHashCode(item), item);
        }
        public ItemSet GetItemSet(ItemSet item)
        {
            ItemSet s = (ItemSet)base[GetItemHashCode(item)];
             GetItemHashCode(item);
            return s;
        }
        public int GetItemHashCode(ItemSet item)
        {
            
            
            StringBuilder s =new StringBuilder( item.Level.ToString());
            s.Append(item.Items[item.Level - 1].ToString());
            if (item.Level >1)
            {
                s .Append( item.Items[item.Level - 2].ToString());
            }
            if (item.Level > 2)
            {
                s.Append(item.Items[item.Level - 3].ToString());
            }
            
            
            s.Append(s.ToString().GetHashCode());
            //Console.WriteLine(s.ToString());
            return s.ToString().GetHashCode();
        }//end method

        public void Add(ItemSet item) { 
        
            if(item !=null){
                base.Add(GetItemHashCode(item), item);
            }
        
        }
        public void AddRange(ItemSet[] items) {

            if (items != null && items.Length > 1)
            {
                for (int i = 0; i < items.Length; i++)
                {
                    Add(items[i]);
                }
                //for (int i = 0; i < items.Length; i++)
                //{
                //    Console.Write(GetItemHashCode(items[i]) + ",");
                //}
            }
            
            
        
        }//

       
    }
}
