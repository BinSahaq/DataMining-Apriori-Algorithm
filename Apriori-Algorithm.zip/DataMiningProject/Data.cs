﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;

namespace DataminingProject
{
    public enum ConnectionType
    {
        OleDb,
        SqlDb

    };

   public  class Data
    {
       
       
        /// <summary>
        /// get the dataset from the access database,make connection ,retrieve data and fill 
        /// it in string[][] data
        /// </summary>
        /// <returns>string [][]</returns>
        public static string[][] get_data(object c,ConnectionType ct )
        {
            if (ct == ConnectionType.OleDb)
            {   
                //string conn_string = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ahmed\Desktop\access.accdb";
                OleDbConnection conn = (OleDbConnection) c;
                //test the connection 
                try
                {
                    if(conn.State==ConnectionState.Closed)
                        conn.Open();
                    if (conn.State == ConnectionState.Open)
                        Console.WriteLine("Connection opened");
                }
                catch (OleDbException exp)
                {
                    Console.WriteLine(exp.Message);
                }

                OleDbCommand count_cmd = new OleDbCommand(@"select count(*) from transactionstable;");
                count_cmd.Connection = conn;
                int num_rows = (int)count_cmd.ExecuteScalar();

                OleDbCommand cmd = new OleDbCommand(@"select * from transactionstable;");
                cmd.Connection = conn;
                OleDbDataReader rd = cmd.ExecuteReader();
                //int num_cols = rd.FieldCount;
                //Console.WriteLine("The number of columns :{0},the number of rows: {1} ", num_cols, num_rows);
                //create data array 

                string[][] data = new string[num_rows][];
                int i = 0;
                while (rd.Read())
                {

                    data[i] = new string[rd.FieldCount - 1];          //exclude the tid

                    for (int j = 0; j < data[i].Length; j++)
                    {
                        if (!rd.IsDBNull(j + 1))
                        {
                            data[i][j] = (string)rd[j + 1];
                        }
                    }
                    i++;
                }
                conn.Close();

                return data;
            }
            else if (ct ==ConnectionType.SqlDb){
                return null;
            }
            return null;
        }//end method  get_data
    }//end class data
}
