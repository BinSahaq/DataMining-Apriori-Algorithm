﻿namespace DataMiningProject
{
    //partial class Form3
    //{
    //    /// <summary>
    //    /// Required designer variable.
    //    /// </summary>
    //    private System.ComponentModel.IContainer components = null;

    //    /// <summary>
    //    /// Clean up any resources being used.
    //    /// </summary>
    //    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    //    protected override void Dispose(bool disposing)
    //    {
    //        if (disposing && (components != null))
    //        {
    //            components.Dispose();
    //        }
    //        base.Dispose(disposing);
    //    }

    //    #region Windows Form Designer generated code

    //    /// <summary>
    //    /// Required method for Designer support - do not modify
    //    /// the contents of this method with the code editor.
    //    /// </summary>
    //    private void InitializeComponent()
    //    {
    //        this.comboBox1 = new System.Windows.Forms.ComboBox();
    //        this.panel1 = new System.Windows.Forms.Panel();
    //        this.btn_ok = new System.Windows.Forms.Button();
    //        this.btn_cancel = new System.Windows.Forms.Button();
    //        this.label1 = new System.Windows.Forms.Label();
    //        this.SuspendLayout();
    //        // 
    //        // comboBox1
    //        // 
    //        this.comboBox1.FormattingEnabled = true;
    //        this.comboBox1.Items.AddRange(new object[] {
    //        "Access",
    //        "Oracle ",
    //        "Sql",
    //        "xml"});
    //        this.comboBox1.Location = new System.Drawing.Point(184, 320);
    //        this.comboBox1.Name = "comboBox1";
    //        this.comboBox1.Size = new System.Drawing.Size(218, 21);
    //        this.comboBox1.TabIndex = 1;
    //        this.comboBox1.Text = "Access";
    //        this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
    //        // 
    //        // panel1
    //        // 
    //        this.panel1.AutoSize = true;
    //        this.panel1.Location = new System.Drawing.Point(12, 29);
    //        this.panel1.Name = "panel1";
    //        this.panel1.Size = new System.Drawing.Size(390, 240);
    //        this.panel1.TabIndex = 2;
    //        // 
    //        // btn_ok
    //        // 
    //        this.btn_ok.Location = new System.Drawing.Point(246, 376);
    //        this.btn_ok.Name = "btn_ok";
    //        this.btn_ok.Size = new System.Drawing.Size(75, 23);
    //        this.btn_ok.TabIndex = 3;
    //        this.btn_ok.Text = "Ok";
    //        this.btn_ok.UseVisualStyleBackColor = true;
    //        this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
    //        // 
    //        // btn_cancel
    //        // 
    //        this.btn_cancel.Location = new System.Drawing.Point(327, 376);
    //        this.btn_cancel.Name = "btn_cancel";
    //        this.btn_cancel.Size = new System.Drawing.Size(75, 23);
    //        this.btn_cancel.TabIndex = 4;
    //        this.btn_cancel.Text = "Cancel";
    //        this.btn_cancel.UseVisualStyleBackColor = true;
    //        this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
    //        // 
    //        // label1
    //        // 
    //        this.label1.AutoSize = true;
    //        this.label1.Location = new System.Drawing.Point(21, 320);
    //        this.label1.Name = "label1";
    //        this.label1.Size = new System.Drawing.Size(113, 13);
    //        this.label1.TabIndex = 5;
    //        this.label1.Text = "DataBase  Connetcor:";
    //        // 
    //        // Form3
    //        // 
    //        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
    //        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
    //        this.ClientSize = new System.Drawing.Size(414, 411);
    //        this.Controls.Add(this.label1);
    //        this.Controls.Add(this.btn_cancel);
    //        this.Controls.Add(this.btn_ok);
    //        this.Controls.Add(this.panel1);
    //        this.Controls.Add(this.comboBox1);
    //        this.Name = "Form3";
    //        this.Text = "Form1";
    //        this.Load += new System.EventHandler(this.Form1_Load);
    //        this.ResumeLayout(false);
    //        this.PerformLayout();

    //    }

    //    #endregion

    //    private System.Windows.Forms.ComboBox comboBox1;
    //    private System.Windows.Forms.Panel panel1;
    //    private System.Windows.Forms.Button btn_ok;
    //    private System.Windows.Forms.Button btn_cancel;
    //    private System.Windows.Forms.Label label1;
    //}
}

