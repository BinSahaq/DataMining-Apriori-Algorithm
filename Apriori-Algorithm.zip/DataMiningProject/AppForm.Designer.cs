﻿namespace DataminingProject
{
    partial class AppForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btn_Disconnect = new System.Windows.Forms.Button();
            this.btn_displayDataset = new System.Windows.Forms.Button();
            this.btnStartAnalysis = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtMin_support = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMin_confidance = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_DispFreqItemSets = new System.Windows.Forms.Button();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.splitContainer1.Panel1.Controls.Add(this.btn_DispFreqItemSets);
            this.splitContainer1.Panel1.Controls.Add(this.btn_Disconnect);
            this.splitContainer1.Panel1.Controls.Add(this.btn_displayDataset);
            this.splitContainer1.Panel1.Controls.Add(this.btnStartAnalysis);
            this.splitContainer1.Panel1.Controls.Add(this.btnConnect);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.Silver;
            this.splitContainer1.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.splitContainer1.Size = new System.Drawing.Size(795, 559);
            this.splitContainer1.SplitterDistance = 144;
            this.splitContainer1.TabIndex = 0;
            // 
            // btn_Disconnect
            // 
            this.btn_Disconnect.Enabled = false;
            this.btn_Disconnect.Location = new System.Drawing.Point(12, 81);
            this.btn_Disconnect.Name = "btn_Disconnect";
            this.btn_Disconnect.Size = new System.Drawing.Size(105, 23);
            this.btn_Disconnect.TabIndex = 3;
            this.btn_Disconnect.Text = "Disconnect";
            this.btn_Disconnect.UseVisualStyleBackColor = true;
            this.btn_Disconnect.Click += new System.EventHandler(this.btn_Disconnect_Click);
            // 
            // btn_displayDataset
            // 
            this.btn_displayDataset.Enabled = false;
            this.btn_displayDataset.Location = new System.Drawing.Point(12, 416);
            this.btn_displayDataset.Name = "btn_displayDataset";
            this.btn_displayDataset.Size = new System.Drawing.Size(107, 23);
            this.btn_displayDataset.TabIndex = 2;
            this.btn_displayDataset.Text = "Display Dataset";
            this.btn_displayDataset.UseVisualStyleBackColor = true;
            this.btn_displayDataset.Click += new System.EventHandler(this.btn_displayDataset_Click);
            // 
            // btnStartAnalysis
            // 
            this.btnStartAnalysis.Enabled = false;
            this.btnStartAnalysis.Location = new System.Drawing.Point(12, 471);
            this.btnStartAnalysis.Name = "btnStartAnalysis";
            this.btnStartAnalysis.Size = new System.Drawing.Size(107, 23);
            this.btnStartAnalysis.TabIndex = 1;
            this.btnStartAnalysis.Text = "Start Analysis";
            this.btnStartAnalysis.UseVisualStyleBackColor = true;
            this.btnStartAnalysis.Click += new System.EventHandler(this.btnStartAnalysis_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(12, 40);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(107, 23);
            this.btnConnect.TabIndex = 0;
            this.btnConnect.Text = "ConnectDatabase";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtMin_support);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtMin_confidance);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 174);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(129, 232);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "User ThreShold";
            // 
            // txtMin_support
            // 
            this.txtMin_support.Location = new System.Drawing.Point(26, 61);
            this.txtMin_support.Name = "txtMin_support";
            this.txtMin_support.Size = new System.Drawing.Size(63, 20);
            this.txtMin_support.TabIndex = 6;
            this.txtMin_support.Text = "20";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(95, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "%";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(95, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "%";
            // 
            // txtMin_confidance
            // 
            this.txtMin_confidance.Location = new System.Drawing.Point(26, 146);
            this.txtMin_confidance.Name = "txtMin_confidance";
            this.txtMin_confidance.Size = new System.Drawing.Size(63, 20);
            this.txtMin_confidance.TabIndex = 3;
            this.txtMin_confidance.Text = "50";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Min_Confidance:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Min_support:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.splitContainer1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(795, 559);
            this.panel1.TabIndex = 1;
            // 
            // btn_DispFreqItemSets
            // 
            this.btn_DispFreqItemSets.Enabled = false;
            this.btn_DispFreqItemSets.Location = new System.Drawing.Point(12, 526);
            this.btn_DispFreqItemSets.Name = "btn_DispFreqItemSets";
            this.btn_DispFreqItemSets.Size = new System.Drawing.Size(107, 23);
            this.btn_DispFreqItemSets.TabIndex = 4;
            this.btn_DispFreqItemSets.Text = "View FreqItemSets";
            this.btn_DispFreqItemSets.UseVisualStyleBackColor = true;
            this.btn_DispFreqItemSets.Click += new System.EventHandler(this.btn_DispFreqItemSets_Click);
            // 
            // AppForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 559);
            this.Controls.Add(this.panel1);
            this.IsMdiContainer = true;
            this.Name = "AppForm";
            this.Text = "AppForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AppForm_FormClosed);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnStartAnalysis;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox txtMin_confidance;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_displayDataset;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMin_support;
        private System.Windows.Forms.Button btn_Disconnect;
        private System.Windows.Forms.Button btn_DispFreqItemSets;
    }
}

