﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DataMiningProject
{
    public partial class Form3 : Form
    {
        OleDbConnection con;
        public OleDbConnection DataConnection
        {
            get
            {
                return con;
            }
        }
        public Form3()
        {
            InitializeComponent();
            con = new OleDbConnection();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1_SelectedIndexChanged(comboBox1, null);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = (ComboBox)sender;
            if (cb.SelectedIndex == 0 || cb.SelectedIndex == 3)
            {
                AccessControl ac = new AccessControl();

                panel1.Controls.Clear();
                panel1.Controls.Add(ac);
            }
            else
            {
                panel1.Controls.Clear();
                //  SqlControl sql = new SqlControl();
                // panel1.Controls.Add(sql);
            }


        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        //make the connection to the databases and check that every thing is ok
        private void btn_ok_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Access")
            {
                AccessControl ac = (AccessControl)panel1.Controls[0];
                if (ac.FileName != "")
                {
                    string s = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ac.FileName;
                    OleDbConnection conn = new OleDbConnection(s);
                    try
                    {
                        //conn.Open();
                        //if (conn.State == ConnectionState.Open)
                        //{
                        //    MessageBox.Show("Connection opened");

                        //}
                        //con = conn;

                    }
                    catch (OleDbException exp)
                    {
                        MessageBox.Show(exp.Message);
                    }
                }

            }
            else
            {
                SqlControl sc = (SqlControl)panel1.Controls[0];

            }

            this.Close();
        }


    }
}
