﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DataminingProject
{
    public partial class DataConnectionForm : Form
    {
        OleDbConnection oleConn;

        public OleDbConnection DataConnection {

            get {
                return oleConn;
            }
        }
        public DataConnectionForm()
        {
            InitializeComponent();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmb_database_SelectedValueChanged(object sender, EventArgs e)
        {
            
            
            
            }//end method

        private void btn_Ok_Click(object sender, EventArgs e)
        {
            if (cmb_database.SelectedItem.ToString() == "Microsoft Access Database") {
                AccessControl ac=(AccessControl)panel1.Controls[0];
                
                if (ac.FileName !="") {
                    string connStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ac.FileName;
                    oleConn = new OleDbConnection(connStr);
                    this.Close();
                
                }//
            }
        }

        private void DataConnectionForm_Load(object sender, EventArgs e)
        {
            
            cmb_database_SelectedIndexChanged(cmb_database, null);
        }

        private void cmb_database_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = (ComboBox)sender;
            panel1.Controls.Clear();
            if (cb.SelectedItem.ToString() == "Microsoft Access Database")
            {
                AccessControl c = new AccessControl();
                panel1.Controls.Add(c);
            }
                    

           
        }
        }

              
    }

