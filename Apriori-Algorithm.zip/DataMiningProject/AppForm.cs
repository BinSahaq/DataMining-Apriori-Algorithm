﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Collections;
using System.Xml;


namespace DataminingProject
{
    /// <summary>
    /// Main application form 
    /// </summary>
    public partial class AppForm : Form
    {
        Apriori p;

        DataGridView dataview;
        OleDbConnection conn;

        int trans_nums;
        double min_support;
        double min_confidance;

        private List<AssocRule> Rules;

        public AppForm()
        {
            InitializeComponent();


        }


        private void display_dataset()
        {

            if (conn != null && conn.State == ConnectionState.Open)
            {
                try
                {

                    OleDbCommand cmd = new OleDbCommand(@"select * from transactionstable");
                    cmd.Connection = conn;
                    DataSet ds = new DataSet("Transactions");
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    da.Fill(ds, "transactionstable");

                    // the dataview
                    splitContainer1.Panel2.Controls.Clear();
                    dataview = new DataGridView();
                    dataview.ReadOnly = true;
                    dataview.AllowDrop = false;
                    dataview.AllowUserToAddRows = false;
                    dataview.AllowUserToDeleteRows = false;
                    dataview.AllowUserToResizeColumns = false;
                    dataview.AllowUserToResizeRows = false;
                    //display headers
                    foreach (DataColumn c in ds.Tables["transactionstable"].Columns)
                    {
                        dataview.Columns.Add(c.ColumnName, c.ColumnName);

                    }//

                    //display the data
                    foreach (DataRow r in ds.Tables["transactionstable"].Rows)
                    {
                        dataview.Rows.Add(r.ItemArray);

                    }//

                    //dataview.Enabled = false;

                    dataview.Dock = DockStyle.Fill;
                    splitContainer1.Panel2.Controls.Add(dataview);


                }
                catch (OleDbException exp)
                {
                    MessageBox.Show(exp.Message);

                }
            }

            else
            {
                MessageBox.Show("Please connect to the database you want to analiyze");

            }

        }
        private void btnConnect_Click(object sender, EventArgs e)
        {
            DataConnectionForm f = new DataConnectionForm();

            f.ShowDialog();
            conn = f.DataConnection;
            if (conn != null)
            {
                //opening the connection
                try
                {
                    conn.Open();
                    btn_displayDataset.Enabled = true;
                    btnStartAnalysis.Enabled = true;
                    btn_Disconnect.Enabled = true;
                }
                catch (OleDbException exp)
                {
                    MessageBox.Show(exp.Message);

                }

            }

        }

        private void DisplayFrequentItemList(Apriori p1)
        {


            if (p1 != null)
            {
                splitContainer1.Panel2.Controls.Clear();

                DataGridView list = new DataGridView();
                list.Columns.Add("Set Num", "SetNum");
                list.Columns.Add("Items", "Items");
                list.Columns.Add("Support_Count", "Support_Count");

                list.Dock = DockStyle.Fill;
                list.ReadOnly = true;
                list.AutoSize = true;
                string[] values = new string[3];

                //for (int i = 0; i < ; i++)
                //{
                //    values[0] = (i + 1).ToString();
                //    values[1] = (String.Join(" & ", (string[])(Rules[i].LHS.Items.ToArray(typeof(string)))));
                //    values[2] = (String.Join(" & ", (string[])(Rules[i].RHS.Items.ToArray(typeof(string)))));
                //    values[3] = Math.Round(Rules[i].Confidance).ToString();
                //    list.Rows.Add(values);

                //}//

                list.Show();
                splitContainer1.Panel2.Controls.Add(list);

            }
        }

        private void btn_displayDataset_Click(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Open)
            {
                display_dataset();
            }
            else
            {

                try
                {
                    conn.Open();
                    display_dataset();
                }
                catch (OleDbException exp)
                {
                    MessageBox.Show(exp.Message);
                }
            }

        }
        

        private void btnStartAnalysis_Click(object sender, EventArgs e)
        {
            double n1, n2;
            if (Double.TryParse(txtMin_support.Text.Trim(), out n1) && Double.TryParse(txtMin_confidance.Text.Trim(), out n2))
            {

                if (conn.GetType() == typeof(OleDbConnection))
                {
                    string[][] dataset = Data.get_data(conn, ConnectionType.OleDb);

                    if (dataset != null && dataset.Length > 0)
                    {
                        trans_nums = dataset.GetUpperBound(0) + 1;
                        min_support = Math.Floor((n1 * trans_nums) / 100);
                        min_confidance = n2;
                        p = new Apriori(dataset, min_support, min_confidance);
                        p.find_assoc_rules();
                        Rules = new List<AssocRule>();

                        Rules = p.get_assoc_rules();

                        if (Rules != null && Rules.Count > 0 && MessageBox.Show("The analysis is complete did you want to display the result") == DialogResult.OK)
                        {
                            DisplayRules(Rules);

                            if (MessageBox.Show(this, "Do you want to save the resulted rules", "Save File", MessageBoxButtons.OKCancel) == DialogResult.OK)
                            {
                                SaveFileDialog f = new SaveFileDialog();
                                f.Filter = "Xml File |*.xml";
                                f.ShowDialog();

                                string s = f.FileName;
                                if (s != "")
                                {
                                    XmlTextWriter xmlfile = new XmlTextWriter(s, Encoding.ASCII);
                                    xmlfile.Formatting = Formatting.Indented;
                                    xmlfile.WriteStartElement("AssocitionRules");
                                    for (int j = 0; j < Rules.Count; j++)
                                    {
                                        xmlfile.WriteStartElement("Rule");
                                        xmlfile.WriteStartAttribute("Num");
                                        xmlfile.WriteString((j + 1).ToString());
                                        xmlfile.WriteEndAttribute();
                                        xmlfile.WriteStartElement("LHS");
                                        xmlfile.WriteString((String.Join(",", (string[])Rules[j].LHS.Items.ToArray(typeof(string)))));
                                        xmlfile.WriteEndElement();
                                        xmlfile.WriteStartElement("RHS");
                                        xmlfile.WriteString((String.Join(",", (string[])Rules[j].RHS.Items.ToArray(typeof(string)))));
                                        xmlfile.WriteEndElement();
                                        xmlfile.WriteStartElement("Confidance");
                                        xmlfile.WriteString(Rules[j].Confidance.ToString());
                                        xmlfile.WriteEndElement();
                                        xmlfile.WriteEndElement();


                                    }
                                    xmlfile.WriteEndElement();

                                    xmlfile.Close();
                                }
                            }

                        }

                    }
                    else
                    {
                        MessageBox.Show("There is no data in the dataset");
                    }
                }
                else
                {

                }

            }
            else
            {
                MessageBox.Show("Please Enter min_support and min_confidance (in numbers)");
            }
        }

        private void DisplayRules(List<AssocRule> Rules)
        {
            splitContainer1.Panel2.Controls.Clear();

            DataGridView list = new DataGridView();
            list.Columns.Add("RuleNum", "RuleNum");
            list.Columns.Add("LHS", "LHS");
            list.Columns.Add("RHS", "RHS");
            list.Columns.Add("Confidance", "Confidance  %");
            list.Dock = DockStyle.Fill;
            list.ReadOnly = true;
            list.AutoSize = true;
            string[] values = new string[4];
            for (int i = 0; i < Rules.Count; i++)
            {
                values[0] = (i + 1).ToString();
                values[1] = (String.Join(" & ", (string[])(Rules[i].LHS.Items.ToArray(typeof(string)))));
                values[2] = (String.Join(" & ", (string[])(Rules[i].RHS.Items.ToArray(typeof(string)))));
                values[3] = Math.Round(Rules[i].Confidance).ToString();
                list.Rows.Add(values);

            }//

            list.Show();
            splitContainer1.Panel2.Controls.Add(list);
        }

        private void txtMin_support_Validating(object sender, CancelEventArgs e)
        {

        }

        private void btn_Disconnect_Click(object sender, EventArgs e)
        {
            if (conn != null && conn.State == ConnectionState.Open)
            {
                conn.Close();

            }
            btn_displayDataset.Enabled = false;
            btnStartAnalysis.Enabled = false;
            btn_Disconnect.Enabled = false;
        }

        private void AppForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (conn != null && conn.State == ConnectionState.Open)
                conn.Close();
        }

        private void btn_DispFreqItemSets_Click(object sender, EventArgs e)
        {

        }




    }
}

