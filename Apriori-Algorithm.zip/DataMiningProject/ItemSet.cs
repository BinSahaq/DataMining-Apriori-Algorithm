﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace DataminingProject
{
    /// <summary>
    /// class ItemSet represent set of items of specific a number (level) items in it 
    /// </summary>
    /// 
    public class ItemSet
    {

        //data members

        private ArrayList items;
        private int count;
        private int level;

        /// <summary>
        /// constructors
        /// </summary>

        public ItemSet(ArrayList it)
        {
            items = it;
            count = 0;
            level = it.Count;
        }
        public ItemSet()
        {
            items = new ArrayList();
            count = 0;
            level = items.Count;
        }

        //Properties
        /// <summary>
        ///  SortedList <int ,string>Items
        ///  return the items in a set
        /// </summary>
        public ArrayList Items
        {
            set
            {
                items = value;
            }
            get
            {
                return items;

            }
        }//

        public int Count
        {
            set
            {
                count = value;
            }
            get
            {
                return count;
            }
        }//
        public int Level
        {
            set
            {
                level = value;
            }
            get
            {
                return level = Items.Count;
            }

        }
        //



        public static ItemSet Union(ItemSet l, ItemSet s)
        {

            if (l.Level > 0 && s.Level > 0)
            {
                ItemSet temp = l;
                for (int i = 0; i < s.Level; i++)
                {
                    if (!temp.Items.Contains(s.Items[i]))
                    {
                        temp.Items.Add(s.Items[i]);

                    }

                }
                return temp;
            }
            return null;
        }//end method operator +


        /// <summary>
        /// implement the ItemSets substaction l-s
        /// </summary>
        /// <param name="l"></param>
        /// <param name="s"></param>
        /// <returns>ItemSet </returns>
        public static ItemSet Minus(ItemSet l, ItemSet s)
        {
            if (l.Level > s.Level)
            {
                ItemSet temp = new ItemSet();
                for (int i = 0; i < l.Level; i++)
                {
                    if (!s.Items.Contains(l.Items[i]))
                    {
                        temp.Items.Add(l.Items[i]);

                    }
                }
                temp.Items.TrimToSize();
                return temp;
            }
            return null;
              
        }//end method operator -

        /// <summary>
        /// determine if the two ItemSets l and s are equal mean l is s and s is l (the same in values)
        /// </summary>
        /// <param name="l"></param>
        /// <param name="s"></param>
        /// <returns></returns>
        public static bool IsEqual(ItemSet l, ItemSet s)
        {
            for (int i = 0; i < l.Level; i++)
            {
                if (l.Items[i] != s.Items[i])
                {
                    return false;
                }
            }
            return true;
        }//end method IsEqual

        /// <summary>
        /// determine if ItemSet s1 is subset of ItemSet s2
        /// </summary>
        /// <param name="s1"></param>
        /// <param name="s2"></param>
        /// <returns></returns>

        public static bool IsSubsetOf(ItemSet s1, ItemSet s2)
        {
            foreach (object item in s1.Items)
            {
                if (!s2.Items.Contains(item))
                    return false;
            }
            return true;
        }//end method IsSubsetOf

        //generate  k-items subset 
        private static ItemSet[] gen_kitem_subset(ItemSet[] Lk_1)
        {
            if (Lk_1 != null && Lk_1.Length > 0)
            {
                ArrayList Ck = new ArrayList();

                bool flag = true;
                int j;

                //join l1 and l2 
                foreach (ItemSet l1 in Lk_1)
                {

                    foreach (ItemSet l2 in Lk_1)
                    {
                        ItemSet c = new ItemSet();

                        for (j = 0; j < l1.Level - 1; j++)
                        {
                            if (l1.Items[j] != l2.Items[j])
                            {
                                flag = false;
                                break;
                            }

                        }
                        if (flag && ((string)l1.Items[j]).CompareTo((string)l2.Items[j]) < 0)
                        {

                            c.Items.InsertRange(0, l1.Items);
                            c.Items.Add(l2.Items[j]);
                            c.Items.TrimToSize();

                            Ck.Add(c);
                        }
                        flag = true;

                    }//end inner for

                }//end outer for

                ItemSet[] ck = (ItemSet[])Ck.ToArray(typeof(ItemSet));

                return ck;
            }
            else
            {
                return null;
            }


        }//end method gen_kitem_subset

        //get list of subsets of ItemSet l
        public static ItemSet[] get_subsets(ItemSet l)
        {
            ArrayList subsets = new ArrayList();
            ArrayList temp;

            if (l.Level > 1)
            {
                //find the 1-item subset;
                foreach (string item in l.Items)
                {
                    temp = new ArrayList();
                    temp.Add(item);
                    ItemSet its = new ItemSet(temp);
                    subsets.Add(its);
                }//end 
                subsets.TrimToSize();
                int k;
                ItemSet[] Lk = (ItemSet[])subsets.ToArray(typeof(ItemSet));
                ItemSet[] Ck;
                for (k = 2; Lk.Length > 1; k++)
                {

                    Ck = gen_kitem_subset(Lk);
                    Lk = Ck;
                    subsets.AddRange(Lk);

                }//

            }
            else
            {
                subsets.Add(l);
            }
            subsets.TrimToSize();

            return (ItemSet[])subsets.ToArray(typeof(ItemSet));
        }//end method  get_subsets
       
        //printing 
        public static void print(ArrayList s)
        {
            foreach (Object c in s)
                Console.Write(c + ",");
            Console.WriteLine();
        }

        public static void print(ItemSet s)
        {
            if (s != null)
            {
                foreach (string ss in s.Items)
                {
                    Console.Write(ss + ",");
                }
            }
            //Console.WriteLine();

        }//end method 

        public static void print_AllFrequentList(ArrayList allFreqLists)
        {

            Console.WriteLine(" \n\nAll the frequent List ");
            foreach (ItemSet[] list in allFreqLists)
            {

                print_freq_itemlist(list);
            }




        }//end method



        public static void print(string[][] data)
        {
            Console.WriteLine();
            for (int i = 0; i < data.Length; i++)
            {
                for (int j = 0; j < data[i].Length; j++)
                {
                    Console.Write(data[i][j] + ",");
                }
                Console.WriteLine();

            }//


        }//end print 

        public static void print_freq_itemlist(ItemSet[] itemset)
        {
            Console.WriteLine("-----ItemSet------");
            foreach (ItemSet its in itemset)
            {
                foreach (string c in its.Items)
                {
                    Console.Write(c + " ");

                }

                Console.Write("(" + its.Count + ")");
                Console.WriteLine();
            }
        }//end print_freq_itemlist



    }//end class ItemSet
}
